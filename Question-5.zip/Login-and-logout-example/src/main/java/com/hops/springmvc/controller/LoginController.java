package com.hops.springmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.hops.springmvc.model.User;

@Controller
public class LoginController {

	@RequestMapping("/")
	public String index() {
		
		return "index.jsp";
	}

	@PostMapping("/login")
	public ModelAndView login(@ModelAttribute("user") User user) {
		ModelAndView mv = new ModelAndView();

		if (user.getEmail().equals("neel@gmail.com") && user.getPassword().equals("neel@123")) {
			
			mv.setViewName("success.jsp");
			mv.addObject("status", "success");
			
		}
		else {
			mv.setViewName("error.jsp");
			mv.addObject("status", "failed");
		}
		
		return mv;
	}

}
