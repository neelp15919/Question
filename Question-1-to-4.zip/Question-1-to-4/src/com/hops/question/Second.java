package com.hops.question;

public class Second {

	public static void main(String[] args) {
	
		
		double res=Math.sqrt(Math.pow(Math.PI * Math.PI, 2));
		
		System.out.println(res);

	}

}
