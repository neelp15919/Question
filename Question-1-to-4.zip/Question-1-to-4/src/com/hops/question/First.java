package com.hops.question;

public class First {

	public static void main(String[] args) {
		
		int result=1;
		int  count=0;
		System.out.print(result);
		for(int i=1;result<10000;i++)
		{
			count++;
			if(i%2!=0)
			{
				System.out.print("+"+i+"=");
				result=result+i;
				System.out.print(result);
			}
			else
			{
				System.out.print("*"+i+"=");
				result=result*i;
				System.out.print(result);
			}
			
		}
		System.out.println("one loop is used and "+count+" times iterate");
		

	}

}
