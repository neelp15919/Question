package com.hops.springmvc.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.web.servlet.ModelAndView;

import com.hops.springmvc.model.User;


public class LoginControllerTest {

	private static LoginController loginController;
	
	@BeforeClass
	public static void before() {
		loginController=new LoginController();
	}

	@Test
	public void testLoginPositive() 
	{
		User user=new User();
		user.setEmail("neel@gmail.com");
		user.setPassword("neel@123");
		
		ModelAndView modelAndView = loginController.login(user);
		
		assertEquals("success", modelAndView.getModel().get("status"));
		//modelAndView.getModel().get(key)
	}
	@Test
	public void testLoginNegative() 
	{
		User user=new User();
		user.setEmail("");
		user.setPassword("");
		
		ModelAndView modelAndView = loginController.login(user);
		
		assertEquals("failed", modelAndView.getModel().get("status"));
		//modelAndView.getModel().get(key)
	}

}

