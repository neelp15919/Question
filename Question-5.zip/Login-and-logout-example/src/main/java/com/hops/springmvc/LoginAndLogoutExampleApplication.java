package com.hops.springmvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoginAndLogoutExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoginAndLogoutExampleApplication.class, args);
	}

}
