package com.hops.question;

import java.util.Arrays;


/**
 * 
 * 
 * 
 * @author neel
 *
 */
public class Third {

	public static void main(String[] args) {
		
		/**
		 *  Here I have done Bubble sort and Insertion Sort
		 *  Insertion sort is best because of no of iteration, time complexity is less copmare to bubble sort
		 * 
		 */

		int arr[] = { 4, 10, 9, 7, 12, 11, 13 };

		int[] bubbleArray = bubbleSort(arr);
			
		int[] insertionArray = insertionSort(arr);
		
		System.out.println(Arrays.toString(bubbleArray));
		
		System.out.println(Arrays.toString(insertionArray));

	}

	private static int[] insertionSort(int[] arr) {

		for(int i=1;i<arr.length;i++)
		{
			int key=arr[i];
			int j=i-1;
			while(j>=0 && arr[j]>key)
			{
				arr[j+1]=arr[j];
				j--;
				
			}
			arr[j+1]=key;
					
			
		}
		
		
		
		return arr;
	}

	private static int[] bubbleSort(int[] arr) {

		for (int i = 0; i < arr.length - 1; i++) {
			for (int j = 0; j < arr.length - i - 1; j++) {

				if (arr[j] > arr[j + 1]) {

					int temp = arr[j];
					arr[j] = arr[j + 1];
					arr[j + 1] = temp;
				}

			}

		}

		return arr;
	}

}
