package com.hops.question;

import java.util.Scanner;

public class Fourth {

	public static void main(String[] args) {
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number:");
		int number=sc.nextInt();
		double result=0;
		
		
		// 1st logic
		//result=(number+1)*Math.pow(number, number);
		
		
		//2nd logic
		for(int i=0;i<=number;i++)
		{
			result=result+Math.pow(number, number);
			
			
		}
		System.out.println(result);
		
	}
	
}
